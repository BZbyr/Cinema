/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import java.util.Date;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author zbyki
 */
public class ScreenTest {
    
    public ScreenTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    /**
     * Test of getScreenId method, of class Screen.
     */
    @Test
    public void testGetScreenId() {
        System.out.println("getScreenId");
        Screen instance = new Screen();
        int expResult = 0;
        int result = instance.getScreenId();
        //assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        //fail("The test case is a prototype.");
    }

    /**
     * Test of getFilmId method, of class Screen.
     */
    @Test
    public void testGetFilmId() {
        System.out.println("getFilmId");
        Screen instance = new Screen();
        int expResult = 0;
        int result = instance.getFilmId();
        //assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        //fail("The test case is a prototype.");
    }

    /**
     * Test of getDate method, of class Screen.
     */
    @Test
    public void testGetDate() {
        System.out.println("getDate");
        Screen instance = new Screen();
        Date expResult = null;
        Date result = instance.getDate();
        //assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        //fail("The test case is a prototype.");
    }

    /**
     * Test of getTimeInterval method, of class Screen.
     */
    @Test
    public void testGetTimeInterval() {
        System.out.println("getTimeInterval");
        Screen instance = new Screen();
        int expResult = 0;
        int result = instance.getTimeInterval();
        //assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        //fail("The test case is a prototype.");
    }

    /**
     * Test of getLeftTicketNum method, of class Screen.
     */
    @Test
    public void testGetLeftTicketNum() {
        System.out.println("getLeftTicketNum");
        Screen instance = new Screen();
        int expResult = 0;
        int result = instance.getLeftTicketNum();
        //assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        //fail("The test case is a prototype.");
    }

    /**
     * Test of getTotalSeatNum method, of class Screen.
     */
    @Test
    public void testGetTotalSeatNum() {
        System.out.println("getTotalSeatNum");
        Screen instance = new Screen();
        int expResult = 0;
        int result = instance.getTotalSeatNum();
        //assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        //fail("The test case is a prototype.");
    }

    /**
     * Test of getLayoutId method, of class Screen.
     */
    @Test
    public void testGetLayoutId() {
        System.out.println("getLayoutId");
        Screen instance = new Screen();
        int expResult = 0;
        int result = instance.getLayoutId();
        //assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        //fail("The test case is a prototype.");
    }

    /**
     * Test of setScreenId method, of class Screen.
     */
    @Test
    public void testSetScreenId() {
        System.out.println("setScreenId");
        int screenId = 0;
        Screen instance = new Screen();
        //instance.setScreenId(screenId);
        // TODO review the generated test code and remove the default call to fail.
        //fail("The test case is a prototype.");
    }

    /**
     * Test of setFilmId method, of class Screen.
     */
    @Test
    public void testSetFilmId() {
        System.out.println("setFilmId");
        int filmId = 0;
        Screen instance = new Screen();
        //instance.setFilmId(filmId);
        // TODO review the generated test code and remove the default call to fail.
        //fail("The test case is a prototype.");
    }

    /**
     * Test of setDate method, of class Screen.
     */
    @Test
    public void testSetDate() {
        System.out.println("setDate");
        Date date = null;
        Screen instance = new Screen();
        //instance.setDate(date);
        // TODO review the generated test code and remove the default call to fail.
        //fail("The test case is a prototype.");
    }

    /**
     * Test of setTimeInterval method, of class Screen.
     */
    @Test
    public void testSetTimeInterval() {
        System.out.println("setTimeInterval");
        int timeInterval = 0;
        Screen instance = new Screen();
        //instance.setTimeInterval(timeInterval);
        // TODO review the generated test code and remove the default call to fail.
        //fail("The test case is a prototype.");
    }

    /**
     * Test of setLeftTicketNum method, of class Screen.
     */
    @Test
    public void testSetLeftTicketNum() {
        System.out.println("setLeftTicketNum");
        int leftTicketNum = 0;
        Screen instance = new Screen();
        //instance.setLeftTicketNum(leftTicketNum);
        // TODO review the generated test code and remove the default call to fail.
        //fail("The test case is a prototype.");
    }

    /**
     * Test of setTotalSeatNum method, of class Screen.
     */
    @Test
    public void testSetTotalSeatNum() {
        System.out.println("setTotalSeatNum");
        int totalSeatNum = 0;
        Screen instance = new Screen();
        //instance.setTotalSeatNum(totalSeatNum);
        // TODO review the generated test code and remove the default call to fail.
        //fail("The test case is a prototype.");
    }

    /**
     * Test of setLayoutId method, of class Screen.
     */
    @Test
    public void testSetLayoutId() {
        System.out.println("setLayoutId");
        int layoutId = 0;
        Screen instance = new Screen();
        //instance.setLayoutId(layoutId);
        // TODO review the generated test code and remove the default call to fail.
        //fail("The test case is a prototype.");
    }
    
}
