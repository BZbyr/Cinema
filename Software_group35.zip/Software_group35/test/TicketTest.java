/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import java.util.Date;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author zbyki
 */
public class TicketTest {
    
    public TicketTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    /**
     * Test of getTicketId method, of class Ticket.
     */
    @Test
    public void testGetTicketId() {
        System.out.println("getTicketId");
        Ticket instance = new Ticket();
        String expResult = "";
        String result = instance.getTicketId();
        //assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        //fail("The test case is a prototype.");
    }

    /**
     * Test of setTicketId method, of class Ticket.
     */
    @Test
    public void testSetTicketId() {
        System.out.println("setTicketId");
        String ticketId = "";
        Ticket instance = new Ticket();
        //instance.setTicketId(ticketId);
        // TODO review the generated test code and remove the default call to fail.
        //fail("The test case is a prototype.");
    }

    /**
     * Test of getFilmId method, of class Ticket.
     */
    @Test
    public void testGetFilmId() {
        System.out.println("getFilmId");
        Ticket instance = new Ticket();
        int expResult = 0;
        int result = instance.getFilmId();
        //assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        //fail("The test case is a prototype.");
    }

    /**
     * Test of setFilmId method, of class Ticket.
     */
    @Test
    public void testSetFilmId() {
        System.out.println("setFilmId");
        int filmId = 0;
        Ticket instance = new Ticket();
       // instance.setFilmId(filmId);
        // TODO review the generated test code and remove the default call to fail.
        //fail("The test case is a prototype.");
    }

    /**
     * Test of getDate method, of class Ticket.
     */
    @Test
    public void testGetDate() {
        System.out.println("getDate");
        Ticket instance = new Ticket();
        Date expResult = null;
        Date result = instance.getDate();
        //assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        //fail("The test case is a prototype.");
    }

    /**
     * Test of setDate method, of class Ticket.
     */
    @Test
    public void testSetDate() {
        System.out.println("setDate");
        Date date = null;
        Ticket instance = new Ticket();
        //instance.setDate(date);
        // TODO review the generated test code and remove the default call to fail.
        //fail("The test case is a prototype.");
    }

    /**
     * Test of getTimeInterval method, of class Ticket.
     */
    @Test
    public void testGetTimeInterval() {
        System.out.println("getTimeInterval");
        Ticket instance = new Ticket();
        int expResult = 0;
        int result = instance.getTimeInterval();
        //assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        //fail("The test case is a prototype.");
    }

    /**
     * Test of setTimeInterval method, of class Ticket.
     */
    @Test
    public void testSetTimeInterval() {
        System.out.println("setTimeInterval");
        int timeInterval = 0;
        Ticket instance = new Ticket();
        //instance.setTimeInterval(timeInterval);
        // TODO review the generated test code and remove the default call to fail.
        //fail("The test case is a prototype.");
    }

    /**
     * Test of getScreenId method, of class Ticket.
     */
    @Test
    public void testGetScreenId() {
        System.out.println("getScreenId");
        Ticket instance = new Ticket();
        int expResult = 0;
        int result = instance.getScreenId();
        //assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        //fail("The test case is a prototype.");
    }

    /**
     * Test of setScreenId method, of class Ticket.
     */
    @Test
    public void testSetScreenId() {
        System.out.println("setScreenId");
        int screenId = 0;
        Ticket instance = new Ticket();
        //instance.setScreenId(screenId);
        // TODO review the generated test code and remove the default call to fail.
        //fail("The test case is a prototype.");
    }

    /**
     * Test of getSeat method, of class Ticket.
     */
    @Test
    public void testGetSeat() {
        System.out.println("getSeat");
        Ticket instance = new Ticket();
        int[] expResult = null;
        int[] result = instance.getSeat();
        //assertArrayEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        //fail("The test case is a prototype.");
    }

    /**
     * Test of setSeat method, of class Ticket.
     */
    @Test
    public void testSetSeat() {
        System.out.println("setSeat");
        int[] seat = null;
        Ticket instance = new Ticket();
        //instance.setSeat(seat);
        // TODO review the generated test code and remove the default call to fail.
        //fail("The test case is a prototype.");
    }

    /**
     * Test of getTicketType method, of class Ticket.
     */
    @Test
    public void testGetTicketType() {
        System.out.println("getTicketType");
        Ticket instance = new Ticket();
        int expResult = 0;
        int result = instance.getTicketType();
        //assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        //fail("The test case is a prototype.");
    }

    /**
     * Test of setTicketType method, of class Ticket.
     */
    @Test
    public void testSetTicketType() {
        System.out.println("setTicketType");
        int ticketType = 0;
        Ticket instance = new Ticket();
        //instance.setTicketType(ticketType);
        // TODO review the generated test code and remove the default call to fail.
        //fail("The test case is a prototype.");
    }

    /**
     * Test of toString method, of class Ticket.
     */
    @Test
    public void testToString() {
        System.out.println("toString");
        Ticket instance = new Ticket();
        String expResult = "";
        //String result = instance.toString();
        //assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        //fail("The test case is a prototype.");
    }

    /**
     * Test of getTypeName method, of class Ticket.
     */
    @Test
    public void testGetTypeName() {
        System.out.println("getTypeName");
        Ticket instance = new Ticket();
        String expResult = "";
        String result = instance.getTypeName();
        //assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        //fail("The test case is a prototype.");
    }

    /**
     * Test of getFilm method, of class Ticket.
     */
    @Test
    public void testGetFilm() {
        System.out.println("getFilm");
        Ticket instance = new Ticket();
        Film expResult = null;
        Film result = instance.getFilm();
        //assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        //fail("The test case is a prototype.");
    }

    /**
     * Test of getRandomID method, of class Ticket.
     */
    @Test
    public void testGetRandomID() {
        System.out.println("getRandomID");
        Ticket instance = new Ticket();
        String expResult = "";
        String result = instance.getRandomID();
        //assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        //fail("The test case is a prototype.");
    }

    /**
     * Test of checkId method, of class Ticket.
     */
    @Test
    public void testCheckId() {
        System.out.println("checkId");
        String randomID = "";
        Ticket instance = new Ticket();
        boolean expResult = false;
        //boolean result = instance.checkId(randomID);
        //assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        //fail("The test case is a prototype.");
    }
    
}
