
/**
 * Created by wangchao on 2017/4/10 0010.
 */

public class launchGUI{
	public static boolean whileFlag = false;
	public static void main(String args[]){
		do {
			mainGUI mGui = new mainGUI();
		}while(whileFlag);
	}
}