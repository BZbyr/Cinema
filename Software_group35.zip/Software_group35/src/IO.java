
import java.util.ArrayList;

/**
 * Created by wangchao on 2017/5/23 0023.
 */
public interface IO {
    public ArrayList readInfo();
    public boolean writeInfo(Object obj);
}
